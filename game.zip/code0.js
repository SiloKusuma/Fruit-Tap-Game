gdjs.HomeCode = {};
gdjs.HomeCode.localVariables = [];
gdjs.HomeCode.idToCallbackMap = new Map();
gdjs.HomeCode.GDLatarObjects1= [];
gdjs.HomeCode.GDLatarObjects2= [];
gdjs.HomeCode.GDLogo_9595HorizontalObjects1= [];
gdjs.HomeCode.GDLogo_9595HorizontalObjects2= [];
gdjs.HomeCode.GDTombol_9595PlayObjects1= [];
gdjs.HomeCode.GDTombol_9595PlayObjects2= [];
gdjs.HomeCode.GDTombol_9595AboutObjects1= [];
gdjs.HomeCode.GDTombol_9595AboutObjects2= [];
gdjs.HomeCode.GDTombol_9595SettingsObjects1= [];
gdjs.HomeCode.GDTombol_9595SettingsObjects2= [];
gdjs.HomeCode.GDPanel_9595SettingsObjects1= [];
gdjs.HomeCode.GDPanel_9595SettingsObjects2= [];
gdjs.HomeCode.GDTombol_9595BantuanObjects1= [];
gdjs.HomeCode.GDTombol_9595BantuanObjects2= [];
gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects1= [];
gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects2= [];


gdjs.HomeCode.mapOfGDgdjs_9546HomeCode_9546GDTombol_95959595SettingsObjects1Objects = Hashtable.newFrom({"Tombol_Settings": gdjs.HomeCode.GDTombol_9595SettingsObjects1});
gdjs.HomeCode.asyncCallback12730348 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.HomeCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Panel_Settings"), gdjs.HomeCode.GDPanel_9595SettingsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Bantuan"), gdjs.HomeCode.GDTombol_9595BantuanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Hapus_Settings"), gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects2);
{for(var i = 0, len = gdjs.HomeCode.GDPanel_9595SettingsObjects2.length ;i < len;++i) {
    gdjs.HomeCode.GDPanel_9595SettingsObjects2[i].setY(175);
}
}
{for(var i = 0, len = gdjs.HomeCode.GDPanel_9595SettingsObjects2.length ;i < len;++i) {
    gdjs.HomeCode.GDPanel_9595SettingsObjects2[i].setX(39);
}
}
{for(var i = 0, len = gdjs.HomeCode.GDTombol_9595BantuanObjects2.length ;i < len;++i) {
    gdjs.HomeCode.GDTombol_9595BantuanObjects2[i].setPosition(440,340);
}
}
{for(var i = 0, len = gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects2.length ;i < len;++i) {
    gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects2[i].setPosition(340,340);
}
}
gdjs.HomeCode.localVariables.length = 0;
}
gdjs.HomeCode.idToCallbackMap.set(12730348, gdjs.HomeCode.asyncCallback12730348);
gdjs.HomeCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.HomeCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.HomeCode.asyncCallback12730348(runtimeScene, asyncObjectsList)), 12730348, asyncObjectsList);
}
}

}


};gdjs.HomeCode.mapOfGDgdjs_9546HomeCode_9546GDTombol_95959595AboutObjects1Objects = Hashtable.newFrom({"Tombol_About": gdjs.HomeCode.GDTombol_9595AboutObjects1});
gdjs.HomeCode.mapOfGDgdjs_9546HomeCode_9546GDTombol_95959595PlayObjects1Objects = Hashtable.newFrom({"Tombol_Play": gdjs.HomeCode.GDTombol_9595PlayObjects1});
gdjs.HomeCode.asyncCallback12732852 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.HomeCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gameplay", false);
}
gdjs.HomeCode.localVariables.length = 0;
}
gdjs.HomeCode.idToCallbackMap.set(12732852, gdjs.HomeCode.asyncCallback12732852);
gdjs.HomeCode.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.HomeCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.HomeCode.asyncCallback12732852(runtimeScene, asyncObjectsList)), 12732852, asyncObjectsList);
}
}

}


};gdjs.HomeCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Tombol_Settings"), gdjs.HomeCode.GDTombol_9595SettingsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.HomeCode.mapOfGDgdjs_9546HomeCode_9546GDTombol_95959595SettingsObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Logo_Horizontal"), gdjs.HomeCode.GDLogo_9595HorizontalObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_About"), gdjs.HomeCode.GDTombol_9595AboutObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Play"), gdjs.HomeCode.GDTombol_9595PlayObjects1);
/* Reuse gdjs.HomeCode.GDTombol_9595SettingsObjects1 */
{gdjs.deviceVibration.startVibration(1);
}
{for(var i = 0, len = gdjs.HomeCode.GDLogo_9595HorizontalObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDLogo_9595HorizontalObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.HomeCode.GDTombol_9595PlayObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDTombol_9595PlayObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.HomeCode.GDTombol_9595AboutObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDTombol_9595AboutObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.HomeCode.GDTombol_9595SettingsObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDTombol_9595SettingsObjects1[i].hide();
}
}

{ //Subevents
gdjs.HomeCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tombol_About"), gdjs.HomeCode.GDTombol_9595AboutObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.HomeCode.mapOfGDgdjs_9546HomeCode_9546GDTombol_95959595AboutObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
{gdjs.deviceVibration.startVibration(1);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "About", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tombol_Play"), gdjs.HomeCode.GDTombol_9595PlayObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.HomeCode.mapOfGDgdjs_9546HomeCode_9546GDTombol_95959595PlayObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
{gdjs.deviceVibration.startVibration(1);
}

{ //Subevents
gdjs.HomeCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Logo_Horizontal"), gdjs.HomeCode.GDLogo_9595HorizontalObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_About"), gdjs.HomeCode.GDTombol_9595AboutObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Play"), gdjs.HomeCode.GDTombol_9595PlayObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Settings"), gdjs.HomeCode.GDTombol_9595SettingsObjects1);
{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}
{for(var i = 0, len = gdjs.HomeCode.GDLogo_9595HorizontalObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDLogo_9595HorizontalObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.HomeCode.GDTombol_9595PlayObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDTombol_9595PlayObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.HomeCode.GDTombol_9595SettingsObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDTombol_9595SettingsObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.HomeCode.GDTombol_9595AboutObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDTombol_9595AboutObjects1[i].hide(false);
}
}
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "The_Juice_Stand.mp3", 0, true, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.HomeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.HomeCode.GDLatarObjects1.length = 0;
gdjs.HomeCode.GDLatarObjects2.length = 0;
gdjs.HomeCode.GDLogo_9595HorizontalObjects1.length = 0;
gdjs.HomeCode.GDLogo_9595HorizontalObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595PlayObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595PlayObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595AboutObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595AboutObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595SettingsObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595SettingsObjects2.length = 0;
gdjs.HomeCode.GDPanel_9595SettingsObjects1.length = 0;
gdjs.HomeCode.GDPanel_9595SettingsObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595BantuanObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595BantuanObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects2.length = 0;

gdjs.HomeCode.eventsList2(runtimeScene);
gdjs.HomeCode.GDLatarObjects1.length = 0;
gdjs.HomeCode.GDLatarObjects2.length = 0;
gdjs.HomeCode.GDLogo_9595HorizontalObjects1.length = 0;
gdjs.HomeCode.GDLogo_9595HorizontalObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595PlayObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595PlayObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595AboutObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595AboutObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595SettingsObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595SettingsObjects2.length = 0;
gdjs.HomeCode.GDPanel_9595SettingsObjects1.length = 0;
gdjs.HomeCode.GDPanel_9595SettingsObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595BantuanObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595BantuanObjects2.length = 0;
gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects1.length = 0;
gdjs.HomeCode.GDTombol_9595Hapus_9595SettingsObjects2.length = 0;


return;

}

gdjs['HomeCode'] = gdjs.HomeCode;
