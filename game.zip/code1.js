gdjs.AboutCode = {};
gdjs.AboutCode.localVariables = [];
gdjs.AboutCode.idToCallbackMap = new Map();


gdjs.AboutCode.eventsList0 = function(runtimeScene) {

};

gdjs.AboutCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.AboutCode.eventsList0(runtimeScene);


return;

}

gdjs['AboutCode'] = gdjs.AboutCode;
