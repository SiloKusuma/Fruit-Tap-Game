gdjs.GameplayCode = {};
gdjs.GameplayCode.localVariables = [];
gdjs.GameplayCode.idToCallbackMap = new Map();
gdjs.GameplayCode.GDLatarObjects1= [];
gdjs.GameplayCode.GDLatarObjects2= [];
gdjs.GameplayCode.GDLatarObjects3= [];
gdjs.GameplayCode.GDBuah_9595ApelObjects1= [];
gdjs.GameplayCode.GDBuah_9595ApelObjects2= [];
gdjs.GameplayCode.GDBuah_9595ApelObjects3= [];
gdjs.GameplayCode.GDBuah_9595JerukObjects1= [];
gdjs.GameplayCode.GDBuah_9595JerukObjects2= [];
gdjs.GameplayCode.GDBuah_9595JerukObjects3= [];
gdjs.GameplayCode.GDBuah_9595LeciObjects1= [];
gdjs.GameplayCode.GDBuah_9595LeciObjects2= [];
gdjs.GameplayCode.GDBuah_9595LeciObjects3= [];
gdjs.GameplayCode.GDLantaiObjects1= [];
gdjs.GameplayCode.GDLantaiObjects2= [];
gdjs.GameplayCode.GDLantaiObjects3= [];
gdjs.GameplayCode.GDTembokObjects1= [];
gdjs.GameplayCode.GDTembokObjects2= [];
gdjs.GameplayCode.GDTembokObjects3= [];
gdjs.GameplayCode.GDMarkerObjects1= [];
gdjs.GameplayCode.GDMarkerObjects2= [];
gdjs.GameplayCode.GDMarkerObjects3= [];
gdjs.GameplayCode.GDSettingsObjects1= [];
gdjs.GameplayCode.GDSettingsObjects2= [];
gdjs.GameplayCode.GDSettingsObjects3= [];
gdjs.GameplayCode.GDBuah_9595DurianObjects1= [];
gdjs.GameplayCode.GDBuah_9595DurianObjects2= [];
gdjs.GameplayCode.GDBuah_9595DurianObjects3= [];
gdjs.GameplayCode.GDPanel_9595SettingsObjects1= [];
gdjs.GameplayCode.GDPanel_9595SettingsObjects2= [];
gdjs.GameplayCode.GDPanel_9595SettingsObjects3= [];
gdjs.GameplayCode.GDTombol_9595BantuanObjects1= [];
gdjs.GameplayCode.GDTombol_9595BantuanObjects2= [];
gdjs.GameplayCode.GDTombol_9595BantuanObjects3= [];
gdjs.GameplayCode.GDPanel_9595AboutObjects1= [];
gdjs.GameplayCode.GDPanel_9595AboutObjects2= [];
gdjs.GameplayCode.GDPanel_9595AboutObjects3= [];
gdjs.GameplayCode.GDCombo_9595OverlayObjects1= [];
gdjs.GameplayCode.GDCombo_9595OverlayObjects2= [];
gdjs.GameplayCode.GDCombo_9595OverlayObjects3= [];
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1= [];
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects2= [];
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects3= [];
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1= [];
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects2= [];
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects3= [];
gdjs.GameplayCode.GDAchievementObjects1= [];
gdjs.GameplayCode.GDAchievementObjects2= [];
gdjs.GameplayCode.GDAchievementObjects3= [];
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1= [];
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects2= [];
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects3= [];
gdjs.GameplayCode.GDPixiDustObjects1= [];
gdjs.GameplayCode.GDPixiDustObjects2= [];
gdjs.GameplayCode.GDPixiDustObjects3= [];


gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595ApelObjects2Objects = Hashtable.newFrom({"Buah_Apel": gdjs.GameplayCode.GDBuah_9595ApelObjects2});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595JerukObjects2Objects = Hashtable.newFrom({"Buah_Jeruk": gdjs.GameplayCode.GDBuah_9595JerukObjects2});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595LeciObjects2Objects = Hashtable.newFrom({"Buah_Leci": gdjs.GameplayCode.GDBuah_9595LeciObjects2});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595DurianObjects1Objects = Hashtable.newFrom({"Buah_Durian": gdjs.GameplayCode.GDBuah_9595DurianObjects1});
gdjs.GameplayCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12786468);
}
}
if (isConditionTrue_0) {
gdjs.GameplayCode.GDBuah_9595ApelObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595ApelObjects2Objects, runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), 150, "");
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595ApelObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595ApelObjects2[i].returnVariable(gdjs.GameplayCode.GDBuah_9595ApelObjects2[i].getVariables().getFromIndex(0)).setString("diatas");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595ApelObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595ApelObjects2[i].activateBehavior("Physics2", false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595ApelObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595ApelObjects2[i].getBehavior("Scale").setScale(0.25);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12787060);
}
}
if (isConditionTrue_0) {
gdjs.GameplayCode.GDBuah_9595JerukObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595JerukObjects2Objects, runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), 150, "");
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects2[i].returnVariable(gdjs.GameplayCode.GDBuah_9595JerukObjects2[i].getVariables().getFromIndex(0)).setString("diatas");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects2[i].activateBehavior("Physics2", false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects2[i].getBehavior("Scale").setScale(0.30);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12789508);
}
}
if (isConditionTrue_0) {
gdjs.GameplayCode.GDBuah_9595LeciObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595LeciObjects2Objects, runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), 150, "");
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects2[i].returnVariable(gdjs.GameplayCode.GDBuah_9595LeciObjects2[i].getVariables().getFromIndex(0)).setString("diatas");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects2[i].activateBehavior("Physics2", false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects2[i].getBehavior("Scale").setScale(0.35);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12791004);
}
}
if (isConditionTrue_0) {
gdjs.GameplayCode.GDBuah_9595DurianObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595DurianObjects1Objects, runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber(), 150, "");
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].returnVariable(gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getVariables().getFromIndex(0)).setString("diatas");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].activateBehavior("Physics2", false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getBehavior("Scale").setScale(0.40);
}
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595ApelObjects1Objects = Hashtable.newFrom({"Buah_Apel": gdjs.GameplayCode.GDBuah_9595ApelObjects1});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595ApelObjects1Objects = Hashtable.newFrom({"Buah_Apel": gdjs.GameplayCode.GDBuah_9595ApelObjects1});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595JerukObjects1Objects = Hashtable.newFrom({"Buah_Jeruk": gdjs.GameplayCode.GDBuah_9595JerukObjects1});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDPixiDustObjects1Objects = Hashtable.newFrom({"PixiDust": gdjs.GameplayCode.GDPixiDustObjects1});
gdjs.GameplayCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameplayCode.GDBuah_9595ApelObjects1 */
gdjs.GameplayCode.GDBuah_9595JerukObjects1.length = 0;

gdjs.GameplayCode.GDPixiDustObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595JerukObjects1Objects, (( gdjs.GameplayCode.GDBuah_9595ApelObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBuah_9595ApelObjects1[0].getPointX("")), (( gdjs.GameplayCode.GDBuah_9595ApelObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBuah_9595ApelObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].returnVariable(gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].getVariables().getFromIndex(0)).setString("dibawah");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].getBehavior("Scale").setScale(0.30);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595ApelObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595ApelObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerCombo");
}
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDPixiDustObjects1Objects, (( gdjs.GameplayCode.GDBuah_9595ApelObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBuah_9595ApelObjects1[0].getPointX("")), (( gdjs.GameplayCode.GDBuah_9595ApelObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBuah_9595ApelObjects1[0].getPointY("")), "");
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595JerukObjects1Objects = Hashtable.newFrom({"Buah_Jeruk": gdjs.GameplayCode.GDBuah_9595JerukObjects1});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595JerukObjects1Objects = Hashtable.newFrom({"Buah_Jeruk": gdjs.GameplayCode.GDBuah_9595JerukObjects1});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595LeciObjects1Objects = Hashtable.newFrom({"Buah_Leci": gdjs.GameplayCode.GDBuah_9595LeciObjects1});
gdjs.GameplayCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameplayCode.GDBuah_9595JerukObjects1 */
gdjs.GameplayCode.GDBuah_9595LeciObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595LeciObjects1Objects, (( gdjs.GameplayCode.GDBuah_9595JerukObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBuah_9595JerukObjects1[0].getPointX("")), (( gdjs.GameplayCode.GDBuah_9595JerukObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBuah_9595JerukObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].returnVariable(gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].getVariables().getFromIndex(0)).setString("dibawah");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].getBehavior("Scale").setScale(0.35);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(2);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerCombo");
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595LeciObjects1Objects = Hashtable.newFrom({"Buah_Leci": gdjs.GameplayCode.GDBuah_9595LeciObjects1});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595LeciObjects1Objects = Hashtable.newFrom({"Buah_Leci": gdjs.GameplayCode.GDBuah_9595LeciObjects1});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595DurianObjects1Objects = Hashtable.newFrom({"Buah_Durian": gdjs.GameplayCode.GDBuah_9595DurianObjects1});
gdjs.GameplayCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameplayCode.GDBuah_9595LeciObjects1 */
gdjs.GameplayCode.GDBuah_9595DurianObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595DurianObjects1Objects, (( gdjs.GameplayCode.GDBuah_9595LeciObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBuah_9595LeciObjects1[0].getPointX("")), (( gdjs.GameplayCode.GDBuah_9595LeciObjects1.length === 0 ) ? 0 :gdjs.GameplayCode.GDBuah_9595LeciObjects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].returnVariable(gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getVariables().getFromIndex(0)).setString("dibawah");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getBehavior("Scale").setScale(0.40);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(3);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TimerCombo");
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDSettingsObjects1Objects = Hashtable.newFrom({"Settings": gdjs.GameplayCode.GDSettingsObjects1});
gdjs.GameplayCode.asyncCallback12803492 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameplayCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Panel_Settings"), gdjs.GameplayCode.GDPanel_9595SettingsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Bantuan"), gdjs.GameplayCode.GDTombol_9595BantuanObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Follow_Tiktok"), gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Follow_Youtube"), gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Hapus_Settings"), gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDPanel_9595SettingsObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPanel_9595SettingsObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects2[i].setPosition(130,497);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects2[i].setPosition(130,620);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595BantuanObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595BantuanObjects2[i].setPosition(440,340);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects2[i].setPosition(340,340);
}
}
gdjs.GameplayCode.localVariables.length = 0;
}
gdjs.GameplayCode.idToCallbackMap.set(12803492, gdjs.GameplayCode.asyncCallback12803492);
gdjs.GameplayCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameplayCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameplayCode.asyncCallback12803492(runtimeScene, asyncObjectsList)), 12803492, asyncObjectsList);
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDTombol_95959595BantuanObjects1Objects = Hashtable.newFrom({"Tombol_Bantuan": gdjs.GameplayCode.GDTombol_9595BantuanObjects1});
gdjs.GameplayCode.asyncCallback12807004 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameplayCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("Panel_About"), gdjs.GameplayCode.GDPanel_9595AboutObjects2);
{for(var i = 0, len = gdjs.GameplayCode.GDPanel_9595AboutObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDPanel_9595AboutObjects2[i].hide(false);
}
}
gdjs.GameplayCode.localVariables.length = 0;
}
gdjs.GameplayCode.idToCallbackMap.set(12807004, gdjs.GameplayCode.asyncCallback12807004);
gdjs.GameplayCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameplayCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameplayCode.asyncCallback12807004(runtimeScene, asyncObjectsList)), 12807004, asyncObjectsList);
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDTombol_95959595Follow_95959595YoutubeObjects1Objects = Hashtable.newFrom({"Tombol_Follow_Youtube": gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1});
gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDTombol_95959595Follow_95959595TiktokObjects1Objects = Hashtable.newFrom({"Tombol_Follow_Tiktok": gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1});
gdjs.GameplayCode.asyncCallback13113692 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameplayCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Achievement"), gdjs.GameplayCode.GDAchievementObjects2);

{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Sembunyi", 1385, "easeInQuad", 0.5, false);
}
}
gdjs.GameplayCode.localVariables.length = 0;
}
gdjs.GameplayCode.idToCallbackMap.set(13113692, gdjs.GameplayCode.asyncCallback13113692);
gdjs.GameplayCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameplayCode.localVariables);
for (const obj of gdjs.GameplayCode.GDAchievementObjects1) asyncObjectsList.addObject("Achievement", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameplayCode.asyncCallback13113692(runtimeScene, asyncObjectsList)), 13113692, asyncObjectsList);
}
}

}


};gdjs.GameplayCode.asyncCallback12816436 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameplayCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Achievement"), gdjs.GameplayCode.GDAchievementObjects2);

{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects2.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects2[i].getBehavior("Tween").addObjectPositionYTween2("Sembunyi", 1385, "easeInQuad", 0.5, false);
}
}
gdjs.GameplayCode.localVariables.length = 0;
}
gdjs.GameplayCode.idToCallbackMap.set(12816436, gdjs.GameplayCode.asyncCallback12816436);
gdjs.GameplayCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameplayCode.localVariables);
for (const obj of gdjs.GameplayCode.GDAchievementObjects1) asyncObjectsList.addObject("Achievement", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameplayCode.asyncCallback12816436(runtimeScene, asyncObjectsList)), 12816436, asyncObjectsList);
}
}

}


};gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDTombol_95959595Hapus_95959595SettingsObjects1Objects = Hashtable.newFrom({"Tombol_Hapus_Settings": gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1});
gdjs.GameplayCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Back");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12784316);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Achievement"), gdjs.GameplayCode.GDAchievementObjects1);
gdjs.copyArray(runtimeScene.getObjects("Combo_Overlay"), gdjs.GameplayCode.GDCombo_9595OverlayObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(false);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(220, 380));
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.randomInRange(0, 3));
}
{for(var i = 0, len = gdjs.GameplayCode.GDCombo_9595OverlayObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCombo_9595OverlayObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].setY(850);
}
}
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
gdjs.GameplayCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buah_Apel"), gdjs.GameplayCode.GDBuah_9595ApelObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.areObjectsColliding(gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595ApelObjects1Objects, "Physics2", gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595ApelObjects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12792604);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameplayCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buah_Jeruk"), gdjs.GameplayCode.GDBuah_9595JerukObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.areObjectsColliding(gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595JerukObjects1Objects, "Physics2", gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595JerukObjects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12795268);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameplayCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buah_Apel"), gdjs.GameplayCode.GDBuah_9595ApelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Buah_Durian"), gdjs.GameplayCode.GDBuah_9595DurianObjects1);
gdjs.copyArray(runtimeScene.getObjects("Buah_Jeruk"), gdjs.GameplayCode.GDBuah_9595JerukObjects1);
gdjs.copyArray(runtimeScene.getObjects("Buah_Leci"), gdjs.GameplayCode.GDBuah_9595LeciObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameplayCode.GDBuah_9595ApelObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].getVariableString(gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].getVariables().get("Status")) == "diatas" ) {
        isConditionTrue_0 = true;
        gdjs.GameplayCode.GDBuah_9595ApelObjects1[k] = gdjs.GameplayCode.GDBuah_9595ApelObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBuah_9595ApelObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].getVariableString(gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].getVariables().get("Status")) == "diatas" ) {
        isConditionTrue_0 = true;
        gdjs.GameplayCode.GDBuah_9595JerukObjects1[k] = gdjs.GameplayCode.GDBuah_9595JerukObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBuah_9595JerukObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].getVariableString(gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].getVariables().get("Status")) == "diatas" ) {
        isConditionTrue_0 = true;
        gdjs.GameplayCode.GDBuah_9595LeciObjects1[k] = gdjs.GameplayCode.GDBuah_9595LeciObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBuah_9595LeciObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getVariableString(gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getVariables().get("Status")) == "diatas" ) {
        isConditionTrue_0 = true;
        gdjs.GameplayCode.GDBuah_9595DurianObjects1[k] = gdjs.GameplayCode.GDBuah_9595DurianObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBuah_9595DurianObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameplayCode.GDBuah_9595ApelObjects1 */
/* Reuse gdjs.GameplayCode.GDBuah_9595DurianObjects1 */
/* Reuse gdjs.GameplayCode.GDBuah_9595JerukObjects1 */
/* Reuse gdjs.GameplayCode.GDBuah_9595LeciObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Marker"), gdjs.GameplayCode.GDMarkerObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595ApelObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].setX(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].setX(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].setX(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].setX(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDMarkerObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMarkerObjects1[i].setY(400);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDMarkerObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMarkerObjects1[i].setX(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDMarkerObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMarkerObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buah_Apel"), gdjs.GameplayCode.GDBuah_9595ApelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Buah_Durian"), gdjs.GameplayCode.GDBuah_9595DurianObjects1);
gdjs.copyArray(runtimeScene.getObjects("Buah_Jeruk"), gdjs.GameplayCode.GDBuah_9595JerukObjects1);
gdjs.copyArray(runtimeScene.getObjects("Buah_Leci"), gdjs.GameplayCode.GDBuah_9595LeciObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameplayCode.GDBuah_9595ApelObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].getVariableString(gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].getVariables().get("Status")) == "diatas" ) {
        isConditionTrue_0 = true;
        gdjs.GameplayCode.GDBuah_9595ApelObjects1[k] = gdjs.GameplayCode.GDBuah_9595ApelObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBuah_9595ApelObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].getVariableString(gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].getVariables().get("Status")) == "diatas" ) {
        isConditionTrue_0 = true;
        gdjs.GameplayCode.GDBuah_9595JerukObjects1[k] = gdjs.GameplayCode.GDBuah_9595JerukObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBuah_9595JerukObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].getVariableString(gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].getVariables().get("Status")) == "diatas" ) {
        isConditionTrue_0 = true;
        gdjs.GameplayCode.GDBuah_9595LeciObjects1[k] = gdjs.GameplayCode.GDBuah_9595LeciObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBuah_9595LeciObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length;i<l;++i) {
    if ( gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getVariableString(gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getVariables().get("Status")) == "diatas" ) {
        isConditionTrue_0 = true;
        gdjs.GameplayCode.GDBuah_9595DurianObjects1[k] = gdjs.GameplayCode.GDBuah_9595DurianObjects1[i];
        ++k;
    }
}
gdjs.GameplayCode.GDBuah_9595DurianObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameplayCode.GDBuah_9595ApelObjects1 */
/* Reuse gdjs.GameplayCode.GDBuah_9595DurianObjects1 */
/* Reuse gdjs.GameplayCode.GDBuah_9595JerukObjects1 */
/* Reuse gdjs.GameplayCode.GDBuah_9595LeciObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Marker"), gdjs.GameplayCode.GDMarkerObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595ApelObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].activateBehavior("Physics2", true);
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].activateBehavior("Physics2", true);
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].activateBehavior("Physics2", true);
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].activateBehavior("Physics2", true);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595ApelObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].returnVariable(gdjs.GameplayCode.GDBuah_9595ApelObjects1[i].getVariables().get("Status")).setString("dibawah");
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595JerukObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].returnVariable(gdjs.GameplayCode.GDBuah_9595JerukObjects1[i].getVariables().get("Status")).setString("dibawah");
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595LeciObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].returnVariable(gdjs.GameplayCode.GDBuah_9595LeciObjects1[i].getVariables().get("Status")).setString("dibawah");
}
for(var i = 0, len = gdjs.GameplayCode.GDBuah_9595DurianObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].returnVariable(gdjs.GameplayCode.GDBuah_9595DurianObjects1[i].getVariables().get("Status")).setString("dibawah");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDMarkerObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDMarkerObjects1[i].hide();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.randomInRange(0, 3));
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setBoolean(true);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Buah_Leci"), gdjs.GameplayCode.GDBuah_9595LeciObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.areObjectsColliding(gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595LeciObjects1Objects, "Physics2", gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDBuah_95959595LeciObjects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12800724);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameplayCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Settings"), gdjs.GameplayCode.GDSettingsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDSettingsObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Panel_About"), gdjs.GameplayCode.GDPanel_9595AboutObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDPanel_9595AboutObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPanel_9595AboutObjects1[i].hide();
}
}

{ //Subevents
gdjs.GameplayCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tombol_Bantuan"), gdjs.GameplayCode.GDTombol_9595BantuanObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDTombol_95959595BantuanObjects1Objects, runtimeScene, false, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Panel_Settings"), gdjs.GameplayCode.GDPanel_9595SettingsObjects1);
/* Reuse gdjs.GameplayCode.GDTombol_9595BantuanObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Tombol_Follow_Tiktok"), gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Follow_Youtube"), gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Hapus_Settings"), gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595BantuanObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595BantuanObjects1[i].setPosition(988,-242);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1[i].setPosition(800,-242);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDPanel_9595SettingsObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPanel_9595SettingsObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1[i].setPosition(809,540);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1[i].setPosition(809,422);
}
}

{ //Subevents
gdjs.GameplayCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() == 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12807972);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Combo_Overlay"), gdjs.GameplayCode.GDCombo_9595OverlayObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDCombo_9595OverlayObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCombo_9595OverlayObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDCombo_9595OverlayObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCombo_9595OverlayObjects1[i].getBehavior("Animation").setAnimationName("Combo 2x");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() == 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12809100);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Combo_Overlay"), gdjs.GameplayCode.GDCombo_9595OverlayObjects1);
{for(var i = 0, len = gdjs.GameplayCode.GDCombo_9595OverlayObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCombo_9595OverlayObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDCombo_9595OverlayObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCombo_9595OverlayObjects1[i].getBehavior("Animation").setAnimationName("Combo 3x");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TimerCombo") > 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Combo_Overlay"), gdjs.GameplayCode.GDCombo_9595OverlayObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0);
}
{for(var i = 0, len = gdjs.GameplayCode.GDCombo_9595OverlayObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDCombo_9595OverlayObjects1[i].hide();
}
}
{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "TimerCombo");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tombol_Follow_Youtube"), gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDTombol_95959595Follow_95959595YoutubeObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://www.youtube.com/@SiloKusuma1", runtimeScene);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tombol_Follow_Tiktok"), gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDTombol_95959595Follow_95959595TiktokObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://www.tiktok.com/SiloKusuma", runtimeScene);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11865524);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Achievement"), gdjs.GameplayCode.GDAchievementObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(5).setBoolean(true);
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].getBehavior("Animation").setAnimationName("Merge 1x");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].setY(800);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Muncul", 680, "easeOutQuad", 0.5, false);
}
}

{ //Subevents
gdjs.GameplayCode.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() == 10);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12815204);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Achievement"), gdjs.GameplayCode.GDAchievementObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(6).setBoolean(true);
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].getBehavior("Animation").setAnimationName("Merge 10x");
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].setY(800);
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDAchievementObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDAchievementObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Muncul", 680, "easeOutQuad", 0.5, false);
}
}

{ //Subevents
gdjs.GameplayCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tombol_Hapus_Settings"), gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameplayCode.mapOfGDgdjs_9546GameplayCode_9546GDTombol_95959595Hapus_95959595SettingsObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Panel_Settings"), gdjs.GameplayCode.GDPanel_9595SettingsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Bantuan"), gdjs.GameplayCode.GDTombol_9595BantuanObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Follow_Tiktok"), gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tombol_Follow_Youtube"), gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1);
/* Reuse gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1 */
{for(var i = 0, len = gdjs.GameplayCode.GDPanel_9595SettingsObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDPanel_9595SettingsObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595BantuanObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595BantuanObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1.length ;i < len;++i) {
    gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1[i].hide();
}
}
}

}


};

gdjs.GameplayCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameplayCode.GDLatarObjects1.length = 0;
gdjs.GameplayCode.GDLatarObjects2.length = 0;
gdjs.GameplayCode.GDLatarObjects3.length = 0;
gdjs.GameplayCode.GDBuah_9595ApelObjects1.length = 0;
gdjs.GameplayCode.GDBuah_9595ApelObjects2.length = 0;
gdjs.GameplayCode.GDBuah_9595ApelObjects3.length = 0;
gdjs.GameplayCode.GDBuah_9595JerukObjects1.length = 0;
gdjs.GameplayCode.GDBuah_9595JerukObjects2.length = 0;
gdjs.GameplayCode.GDBuah_9595JerukObjects3.length = 0;
gdjs.GameplayCode.GDBuah_9595LeciObjects1.length = 0;
gdjs.GameplayCode.GDBuah_9595LeciObjects2.length = 0;
gdjs.GameplayCode.GDBuah_9595LeciObjects3.length = 0;
gdjs.GameplayCode.GDLantaiObjects1.length = 0;
gdjs.GameplayCode.GDLantaiObjects2.length = 0;
gdjs.GameplayCode.GDLantaiObjects3.length = 0;
gdjs.GameplayCode.GDTembokObjects1.length = 0;
gdjs.GameplayCode.GDTembokObjects2.length = 0;
gdjs.GameplayCode.GDTembokObjects3.length = 0;
gdjs.GameplayCode.GDMarkerObjects1.length = 0;
gdjs.GameplayCode.GDMarkerObjects2.length = 0;
gdjs.GameplayCode.GDMarkerObjects3.length = 0;
gdjs.GameplayCode.GDSettingsObjects1.length = 0;
gdjs.GameplayCode.GDSettingsObjects2.length = 0;
gdjs.GameplayCode.GDSettingsObjects3.length = 0;
gdjs.GameplayCode.GDBuah_9595DurianObjects1.length = 0;
gdjs.GameplayCode.GDBuah_9595DurianObjects2.length = 0;
gdjs.GameplayCode.GDBuah_9595DurianObjects3.length = 0;
gdjs.GameplayCode.GDPanel_9595SettingsObjects1.length = 0;
gdjs.GameplayCode.GDPanel_9595SettingsObjects2.length = 0;
gdjs.GameplayCode.GDPanel_9595SettingsObjects3.length = 0;
gdjs.GameplayCode.GDTombol_9595BantuanObjects1.length = 0;
gdjs.GameplayCode.GDTombol_9595BantuanObjects2.length = 0;
gdjs.GameplayCode.GDTombol_9595BantuanObjects3.length = 0;
gdjs.GameplayCode.GDPanel_9595AboutObjects1.length = 0;
gdjs.GameplayCode.GDPanel_9595AboutObjects2.length = 0;
gdjs.GameplayCode.GDPanel_9595AboutObjects3.length = 0;
gdjs.GameplayCode.GDCombo_9595OverlayObjects1.length = 0;
gdjs.GameplayCode.GDCombo_9595OverlayObjects2.length = 0;
gdjs.GameplayCode.GDCombo_9595OverlayObjects3.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects2.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects3.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects2.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects3.length = 0;
gdjs.GameplayCode.GDAchievementObjects1.length = 0;
gdjs.GameplayCode.GDAchievementObjects2.length = 0;
gdjs.GameplayCode.GDAchievementObjects3.length = 0;
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1.length = 0;
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects2.length = 0;
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects3.length = 0;
gdjs.GameplayCode.GDPixiDustObjects1.length = 0;
gdjs.GameplayCode.GDPixiDustObjects2.length = 0;
gdjs.GameplayCode.GDPixiDustObjects3.length = 0;

gdjs.GameplayCode.eventsList8(runtimeScene);
gdjs.GameplayCode.GDLatarObjects1.length = 0;
gdjs.GameplayCode.GDLatarObjects2.length = 0;
gdjs.GameplayCode.GDLatarObjects3.length = 0;
gdjs.GameplayCode.GDBuah_9595ApelObjects1.length = 0;
gdjs.GameplayCode.GDBuah_9595ApelObjects2.length = 0;
gdjs.GameplayCode.GDBuah_9595ApelObjects3.length = 0;
gdjs.GameplayCode.GDBuah_9595JerukObjects1.length = 0;
gdjs.GameplayCode.GDBuah_9595JerukObjects2.length = 0;
gdjs.GameplayCode.GDBuah_9595JerukObjects3.length = 0;
gdjs.GameplayCode.GDBuah_9595LeciObjects1.length = 0;
gdjs.GameplayCode.GDBuah_9595LeciObjects2.length = 0;
gdjs.GameplayCode.GDBuah_9595LeciObjects3.length = 0;
gdjs.GameplayCode.GDLantaiObjects1.length = 0;
gdjs.GameplayCode.GDLantaiObjects2.length = 0;
gdjs.GameplayCode.GDLantaiObjects3.length = 0;
gdjs.GameplayCode.GDTembokObjects1.length = 0;
gdjs.GameplayCode.GDTembokObjects2.length = 0;
gdjs.GameplayCode.GDTembokObjects3.length = 0;
gdjs.GameplayCode.GDMarkerObjects1.length = 0;
gdjs.GameplayCode.GDMarkerObjects2.length = 0;
gdjs.GameplayCode.GDMarkerObjects3.length = 0;
gdjs.GameplayCode.GDSettingsObjects1.length = 0;
gdjs.GameplayCode.GDSettingsObjects2.length = 0;
gdjs.GameplayCode.GDSettingsObjects3.length = 0;
gdjs.GameplayCode.GDBuah_9595DurianObjects1.length = 0;
gdjs.GameplayCode.GDBuah_9595DurianObjects2.length = 0;
gdjs.GameplayCode.GDBuah_9595DurianObjects3.length = 0;
gdjs.GameplayCode.GDPanel_9595SettingsObjects1.length = 0;
gdjs.GameplayCode.GDPanel_9595SettingsObjects2.length = 0;
gdjs.GameplayCode.GDPanel_9595SettingsObjects3.length = 0;
gdjs.GameplayCode.GDTombol_9595BantuanObjects1.length = 0;
gdjs.GameplayCode.GDTombol_9595BantuanObjects2.length = 0;
gdjs.GameplayCode.GDTombol_9595BantuanObjects3.length = 0;
gdjs.GameplayCode.GDPanel_9595AboutObjects1.length = 0;
gdjs.GameplayCode.GDPanel_9595AboutObjects2.length = 0;
gdjs.GameplayCode.GDPanel_9595AboutObjects3.length = 0;
gdjs.GameplayCode.GDCombo_9595OverlayObjects1.length = 0;
gdjs.GameplayCode.GDCombo_9595OverlayObjects2.length = 0;
gdjs.GameplayCode.GDCombo_9595OverlayObjects3.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects1.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects2.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595YoutubeObjects3.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects1.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects2.length = 0;
gdjs.GameplayCode.GDTombol_9595Follow_9595TiktokObjects3.length = 0;
gdjs.GameplayCode.GDAchievementObjects1.length = 0;
gdjs.GameplayCode.GDAchievementObjects2.length = 0;
gdjs.GameplayCode.GDAchievementObjects3.length = 0;
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects1.length = 0;
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects2.length = 0;
gdjs.GameplayCode.GDTombol_9595Hapus_9595SettingsObjects3.length = 0;
gdjs.GameplayCode.GDPixiDustObjects1.length = 0;
gdjs.GameplayCode.GDPixiDustObjects2.length = 0;
gdjs.GameplayCode.GDPixiDustObjects3.length = 0;


return;

}

gdjs['GameplayCode'] = gdjs.GameplayCode;
